(function () {
  'use strict';

  const STORAGE_KEYS = { parties: 'order_parties', products: 'order_products', pending: 'order_pending', version: 'order_app_version' };
  const APP_VERSION = '2'; // Bump to reset parties/products to new sample (KitKat, Dairy Milk, etc.)

  let parties = [];
  let products = [];
  let pendingOrders = [];

  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => el.querySelectorAll(sel);

  function loadFromStorage() {
    try {
      const p = localStorage.getItem(STORAGE_KEYS.parties);
      const pr = localStorage.getItem(STORAGE_KEYS.products);
      const pend = localStorage.getItem(STORAGE_KEYS.pending);
      if (p) parties = JSON.parse(p);
      if (pr) products = JSON.parse(pr);
      if (pend) pendingOrders = JSON.parse(pend);
    } catch (e) {
      console.warn('Storage load failed', e);
    }
  }

  function saveParties() {
    localStorage.setItem(STORAGE_KEYS.parties, JSON.stringify(parties));
  }
  function saveProducts() {
    localStorage.setItem(STORAGE_KEYS.products, JSON.stringify(products));
  }
  function savePending() {
    localStorage.setItem(STORAGE_KEYS.pending, JSON.stringify(pendingOrders));
  }

  function parseFile(file) {
    return new Promise((resolve, reject) => {
      const ext = (file.name || '').toLowerCase();
      const isCsv = ext.endsWith('.csv');
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target.result;
          if (isCsv) {
            const text = typeof data === 'string' ? data : new TextDecoder().decode(data);
            resolve(parseCSV(text));
          } else if (typeof XLSX !== 'undefined') {
            const wb = XLSX.read(data, { type: data instanceof ArrayBuffer ? 'array' : 'binary' });
            const first = wb.SheetNames[0];
            const sheet = wb.Sheets[first];
            resolve(XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' }));
          } else {
            reject(new Error('Excel support: include SheetJS (xlsx) script'));
          }
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      if (isCsv) reader.readAsText(file);
      else reader.readAsArrayBuffer(file);
    });
  }

  function parseCSV(text) {
    const rows = [];
    const lines = text.split(/\r?\n/).filter(Boolean);
    for (const line of lines) {
      const row = [];
      let cur = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') {
          inQuotes = !inQuotes;
        } else if ((c === ',' && !inQuotes) || (c === '\t' && !inQuotes)) {
          row.push(cur.trim());
          cur = '';
        } else {
          cur += c;
        }
      }
      row.push(cur.trim());
      rows.push(row);
    }
    return rows;
  }

  function normalizeParties(rows) {
    if (!rows.length) return [];
    const header = rows[0].map(h => (h || '').toString().toLowerCase());
    const nameCol = header.findIndex(h => h.includes('name') || h.includes('party'));
    const col = nameCol >= 0 ? nameCol : 0;
    const out = [];
    for (let i = 1; i < rows.length; i++) {
      const val = (rows[i][col] || '').toString().trim();
      if (val) out.push({ name: val });
    }
    return out;
  }

  function normalizeProducts(rows) {
    if (!rows.length) return [];
    const header = rows[0].map(h => (h || '').toString().toLowerCase());
    const nameCol = header.findIndex(h => h.includes('name') || h.includes('product') || h.includes('item'));
    const priceCol = header.findIndex(h => h.includes('price') || h.includes('rate'));
    const nCol = nameCol >= 0 ? nameCol : 0;
    const pCol = priceCol >= 0 ? priceCol : 1;
    const out = [];
    for (let i = 1; i < rows.length; i++) {
      const name = (rows[i][nCol] || '').toString().trim();
      const price = parseFloat(rows[i][pCol]) || 0;
      if (name) out.push({ name, price });
    }
    return out;
  }

  const SAMPLE_PARTIES = [
    { name: 'Rahul Agency' },
    { name: 'Sharma Traders' },
    { name: 'Kumar & Co' },
  ];

  const SAMPLE_PRODUCTS = [
    { name: 'KitKat', price: 10 },
    { name: 'Cadbury Dairy Milk', price: 5 },
    { name: 'Parle-G Biscuits', price: 5 },
    { name: 'Maggi Noodles', price: 12 },
    { name: 'Coca-Cola 2L', price: 90 },
    { name: 'Lays Chips', price: 20 },
  ];

  function loadSample() {
    parties = SAMPLE_PARTIES.slice();
    products = SAMPLE_PRODUCTS.slice();
    saveParties();
    saveProducts();
    renderPartiesSelect();
    renderProductsSelect();
    renderDataPreview();
  }

  function renderPartiesSelect() {
    const sel = $('#party-select');
    if (!sel) return;
    const current = sel.value;
    sel.innerHTML = '<option value="">-- Select Party --</option>';
    parties.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.name;
      opt.textContent = p.name;
      sel.appendChild(opt);
    });
    if (current && parties.some(p => p.name === current)) sel.value = current;
  }

  function renderProductsSelect() {
    const container = $('#order-lines-container');
    if (!container) return;
    $$('.product-select', container).forEach(sel => {
      const current = sel.value;
      sel.innerHTML = '<option value="">— Select product —</option>';
      products.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.name;
        opt.textContent = `${p.name} (₹${p.price})`;
        opt.dataset.price = String(p.price);
        sel.appendChild(opt);
      });
      if (current && products.some(p => p.name === current)) sel.value = current;
      syncPriceFromProduct(sel);
    });
  }

  function syncPriceFromProduct(selectEl) {
    const opt = selectEl.options[selectEl.selectedIndex];
    const priceInput = selectEl.closest('.order-line')?.querySelector('.price-input');
    if (priceInput && opt?.dataset.price) priceInput.value = opt.dataset.price;
  }

  function addOrderLine() {
    const container = $('#order-lines-container');
    if (!container) return;
    const first = container.querySelector('.order-line');
    const div = document.createElement('div');
    div.className = 'order-line row';
    div.innerHTML = `
      <select class="product-select" required><option value="">— Select product —</option></select>
      <input type="number" class="price-input" placeholder="Price" min="0" step="0.01" required>
      <input type="number" class="qty-input" placeholder="Qty" min="1" required>
      <button type="button" class="btn btn-remove" aria-label="Remove line">×</button>
    `;
    container.appendChild(div);
    renderProductsSelect();
    div.querySelector('.product-select').addEventListener('change', function () {
      syncPriceFromProduct(this);
    });
    div.querySelector('.btn-remove').addEventListener('click', () => {
      if (container.querySelectorAll('.order-line').length > 1) div.remove();
    });
  }

  function renderDataPreview() {
    const partiesList = $('#parties-list');
    const productsList = $('#products-list');
    const partiesCount = $('#parties-count');
    const productsCount = $('#products-count');
    if (partiesList) {
      partiesList.innerHTML = parties.length ? parties.map(p => `<li>${escapeHtml(p.name)}</li>`).join('') : '<li class="empty">None loaded</li>';
    }
    if (productsList) {
      productsList.innerHTML = products.length ? products.map(p => `<li>${escapeHtml(p.name)} – ₹${p.price}</li>`).join('') : '<li class="empty">None loaded</li>';
    }
    if (partiesCount) partiesCount.textContent = parties.length;
    if (productsCount) productsCount.textContent = products.length;
  }

  function escapeHtml(s) {
    const div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }

  function switchTab(tabId) {
    $$('.tab-panel').forEach(panel => {
      panel.classList.toggle('active', panel.id === tabId + '-tab');
    });
    $$('.header .tab').forEach(t => {
      t.classList.toggle('active', t.dataset.tab === tabId);
    });
    if (tabId === 'pending') renderPendingList();
  }

  function renderPendingList() {
    const listEl = $('#pending-list');
    const printAllBtn = $('#print-all');
    if (!listEl) return;
    if (!pendingOrders.length) {
      listEl.innerHTML = '<p class="empty-state">No pending orders.</p>';
      if (printAllBtn) printAllBtn.disabled = true;
      return;
    }
    if (printAllBtn) printAllBtn.disabled = false;
    listEl.innerHTML = pendingOrders.map((order, idx) => {
      const total = order.items.reduce((sum, it) => sum + it.price * it.qty, 0);
      const rows = order.items.map(
        it => `<tr><td>${escapeHtml(it.product)}</td><td>₹${it.price}</td><td>${it.qty}</td><td>₹${(it.price * it.qty).toFixed(2)}</td></tr>`
      ).join('');
      return `
        <div class="order-block" data-index="${idx}">
          <div class="order-block-header">
            <span class="order-block-title">${escapeHtml(order.party)}</span>
            <span class="order-block-meta">${new Date(order.date).toLocaleString()}</span>
          </div>
          <table class="order-items-table">
            <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Amount</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
          <p class="order-block-meta"><strong>Total: ₹${total.toFixed(2)}</strong></p>
          <div class="order-block-actions">
            <button type="button" class="btn btn-primary btn-print-one" data-index="${idx}">Print</button>
            <button type="button" class="btn btn-outline btn-remove-order" data-index="${idx}">Remove</button>
          </div>
        </div>
      `;
    }).join('');

    listEl.querySelectorAll('.btn-print-one').forEach(btn => {
      btn.addEventListener('click', () => printOrders([pendingOrders[parseInt(btn.dataset.index, 10)]]));
    });
    listEl.querySelectorAll('.btn-remove-order').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = parseInt(btn.dataset.index, 10);
        pendingOrders.splice(i, 1);
        savePending();
        renderPendingList();
      });
    });
  }

  function printOrders(ordersToPrint) {
    const area = $('#print-area');
    if (!area) return;
    const html = ordersToPrint.map(order => {
      const total = order.items.reduce((sum, it) => sum + it.price * it.qty, 0);
      const rows = order.items.map(
        it => `<tr><td>${escapeHtml(it.product)}</td><td>₹${it.price.toFixed(2)}</td><td>${it.qty}</td><td>₹${(it.price * it.qty).toFixed(2)}</td></tr>`
      ).join('');
      return `
        <div class="print-order">
          <h3>${escapeHtml(order.party)}</h3>
          <p>Date: ${new Date(order.date).toLocaleString()}</p>
          <table>
            <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Amount</th></tr></thead>
            <tbody>${rows}</tbody>
            <tfoot><tr class="total-row"><td colspan="3">Total</td><td>₹${total.toFixed(2)}</td></tr></tfoot>
          </table>
        </div>
      `;
    }).join('');
    area.innerHTML = html;
    window.print();
  }

  function submitOrder(e) {
    e.preventDefault();
    const partySel = $('#party-select');
    const party = (partySel && partySel.value) || '';
    if (!party.trim()) return;
    const lines = $$('#order-lines-container .order-line');
    const items = [];
    lines.forEach(row => {
      const productSel = row.querySelector('.product-select');
      const priceIn = row.querySelector('.price-input');
      const qtyIn = row.querySelector('.qty-input');
      const product = (productSel && productSel.value) || '';
      const price = parseFloat(priceIn && priceIn.value) || 0;
      const qty = parseInt(qtyIn && qtyIn.value, 10) || 0;
      if (product && qty > 0) items.push({ product, price, qty });
    });
    if (!items.length) return;
    pendingOrders.push({
      party: party.trim(),
      date: new Date().toISOString(),
      items,
    });
    savePending();
    e.target.reset();
    const firstLine = $('#order-lines-container .order-line');
    if (firstLine && $$('#order-lines-container .order-line').length > 1) {
      $$('#order-lines-container .order-line').forEach((line, i) => {
        if (i > 0) line.remove();
      });
    }
    renderPartiesSelect();
    renderProductsSelect();
    switchTab('pending');
  }

  function init() {
    loadFromStorage();
    var storedVersion = localStorage.getItem(STORAGE_KEYS.version);
    if (storedVersion !== APP_VERSION) {
      localStorage.setItem(STORAGE_KEYS.version, APP_VERSION);
      parties = [];
      products = [];
      loadSample();
    } else if (!parties.length && !products.length) {
      loadSample();
    } else {
      renderPartiesSelect();
      renderProductsSelect();
      renderDataPreview();
    }

    $$('.header .tab').forEach(t => {
      t.addEventListener('click', () => switchTab(t.dataset.tab));
    });

    const form = $('#order-form');
    if (form) {
      form.addEventListener('submit', submitOrder);
    }

    const addLineBtn = $('#add-line');
    if (addLineBtn) addLineBtn.addEventListener('click', addOrderLine);

    $('#order-lines-container')?.querySelectorAll('.product-select').forEach(sel => {
      sel.addEventListener('change', function () {
        syncPriceFromProduct(this);
      });
    });
    $('#order-lines-container')?.querySelector('.btn-remove')?.addEventListener('click', function () {
      const container = $('#order-lines-container');
      if (container && container.querySelectorAll('.order-line').length > 1) this.closest('.order-line')?.remove();
    });

    const printAllBtn = $('#print-all');
    if (printAllBtn) {
      printAllBtn.addEventListener('click', () => printOrders(pendingOrders));
    }

    const partiesFile = $('#parties-file');
    if (partiesFile) {
      partiesFile.addEventListener('change', async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        try {
          const rows = await parseFile(file);
          parties = normalizeParties(rows);
          if (!parties.length) parties = [{ name: 'Unknown' }];
          saveParties();
          renderPartiesSelect();
          renderDataPreview();
        } catch (err) {
          alert('Failed to load parties: ' + (err.message || err));
        }
        e.target.value = '';
      });
    }

    const productsFile = $('#products-file');
    if (productsFile) {
      productsFile.addEventListener('change', async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        try {
          const rows = await parseFile(file);
          products = normalizeProducts(rows);
          if (!products.length) products = [{ name: 'Product', price: 0 }];
          saveProducts();
          renderProductsSelect();
          renderDataPreview();
        } catch (err) {
          alert('Failed to load products: ' + (err.message || err));
        }
        e.target.value = '';
      });
    }

    const loadSampleBtn = $('#load-sample');
    if (loadSampleBtn) loadSampleBtn.addEventListener('click', loadSample);

    renderPendingList();
  }

  init();
})();
