# Order Management Web App

A responsive web application to take and manage orders. Parties and products can be loaded from Excel (.xlsx, .xls) or CSV files. Orders are stored in a Pending Orders tab and can be printed with prices.

## Features

- **New Order**: Select party, add line items (product, price, quantity in Ctn). Price auto-fills from product list.
- **Pending Orders**: View all saved orders with totals. Print individual orders or **Print All (with prices)**.
- **Parties & Products**: Upload Excel/CSV for parties and products, or use **Load Sample Data** (Product A/B/C, Item 1/2/3 with sample prices).
- **Responsive**: Works on desktop and mobile.
- **Persistent**: Data is stored in the browser (localStorage).

## Quick Start

1. Open `index.html` in a browser (or serve the folder with any static server).
2. Go to **Parties & Products** and click **Load Sample Data** (or upload your own Excel/CSV).
3. Go to **New Order**, select a party, add items, and click **Save Order**.
4. Open **Pending Orders** to see orders and use **Print All (with prices)** or **Print** on each order.

## Sample Files

- `sample/parties.csv` – Party names (open in Excel, edit, then upload in the app).
- `sample/products.csv` – Product name and price (open in Excel, edit, then upload).

Excel files should have a header row. For parties, use a column like "Name" or "Party". For products, use "Product"/"Name"/"Item" and "Price".

## Tech

- Vanilla HTML, CSS, JavaScript.
- [SheetJS](https://sheetjs.com/) (xlsx) for Excel/CSV parsing (loaded via CDN).
- No backend; all data stays in the browser.
